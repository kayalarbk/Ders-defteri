# Ders Defteri

Üniversite derslerini organize etmek için modüler, koyu mod destekli statik site.

## Çalıştırma
`index.html` dosyasına çift tıkla — sunucu gerekmez (`file://` ile çalışır).

## İçerik nasıl eklenir?
Tüm içerik **`js/data.js`** içindedir. HTML'e dokunmana gerek yok.

### Yeni ders eklemek
1. `js/data.js` içindeki `DERSLER` nesnesine yeni bir blok ekle:
   ```js
   "EE3099": {
     ad: "Ders Adı",
     donem: "3. Sınıf · 1. Dönem",
     renk: "#4FD1C5",
     ozet: "Kısa açıklama.",
     konular: [], galeri: [], dokumanlar: [], videolar: [], sorular: []
   }
   ```
2. `DERS_SIRASI` dizisine kodu ekle: `["EE3061", ..., "EE3099"]`

### Diğer eklemeler (ilgili dersin bloğunda)
- **Konu:** `konular` dizisine `{ baslik, icerik }` ekle. `icerik` HTML olabilir.
- **Görsel:** Dosyayı `assets/img/` içine koy, `galeri`'ye `{ src, baslik }` ekle.
- **PDF:** Dosyayı `assets/pdf/` içine koy, `dokumanlar`'a `{ ad, dosya, tur }` ekle.
- **Video:** `videolar`'a `{ baslik, youtube }` ekle. `youtube` = sadece video ID'si
  (örn. `https://youtu.be/KuXjwB4LzSA` → `"KuXjwB4LzSA"`).
- **Soru:** `sorular`'a `{ soru, cozum, tip }` ekle. `tip` = `"vize"` veya `"final"`.

### LaTeX / Formül
Satır içi: `\( ... \)` veya `$ ... $`
Blok: `\[ ... \]` veya `$$ ... $$`
MathJax otomatik işler.

## Klasörler
```
index.html · course.html · css/style.css · js/data.js · js/app.js · assets/{img,pdf}
```
